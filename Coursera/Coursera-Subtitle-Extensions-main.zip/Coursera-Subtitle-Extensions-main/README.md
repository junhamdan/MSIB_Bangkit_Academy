# Coursera Subtitle Extension

this is a project to change the language of courses subtitles because I noticed that many people have trouble due to the lack of subtitles in their native language. I thought to myself that I could create a subtitle translator using Google Translate API.

## Supported languages
Persian, English, Turkish, Spanish, French, German, Italian, Portuguese, Russian, Bulgarian, Catalan, Czech, Danish, Dutch, Finnish, Greek, Hindi, Hungarian, Indonesian, Japanese, Korean, Norwegian, Polish, Romanian, Swedish, Thai, Vietnamese.
- If your language is not in the list, send me a message [AmirAnsarpour](https://t.me/AmirAnsarpour).

## Setup
1. Download the project
2. Open your browser add-ons.
3. Activate the Developer mode.
4. Click on install packaged item.
5. Select the folder you downloaded.
6. Installation complete.
7. After opening the course video, select the language and press the translate button.
8. DONE.

## images
<img align="center" src="images/Extension" />
